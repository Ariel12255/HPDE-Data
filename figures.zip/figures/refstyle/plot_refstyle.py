"""Reference-style (smoothed, filled) locus figures for HPDE epigenome.
usage: plot_refstyle.py DATA OUT
DATA: bg/<Mark>_r<n>.bedgraph, genes.tsv, windows.tsv
"""
import sys, os, glob
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrow

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
plt.rcParams["font.family"] = "DejaVu Sans"

# track order mirrors the reference: active marks on top, repressive below, accessibility last
TRACKS = [("K4me3", "H3K4me3", "#5cb85c"), ("K27ac", "H3K27ac", "#f0ad4e"),
          ("K4me1", "H3K4me1", "#e8692c"), ("K27me3", "H3K27me3", "#6b4f3a"),
          ("ATAC", "ATAC-seq", "#2b2f8f")]
GENE_COL = "#2f7fc1"

win = pd.read_csv(f"{DATA}/windows.tsv", sep="\t", header=None, names=["key", "chrom", "start", "end"])
genes = pd.read_csv(f"{DATA}/genes.tsv", sep="\t", header=None,
                    names=["key", "name", "chrom", "start", "end", "strand", "biotype", "exons"]).fillna("")
genes["key"] = genes["key"].replace({"NKX6_1": "NKX6-1"})
TARGET = {"PDX1": ["PDX1"], "NEUROG3": ["NEUROG3"], "MAFA": ["MAFA"], "PAX6": ["PAX6"], "NKX6-1": ["NKX6-1"],
          "NEUROD1": ["NEUROD1"], "PCSK1": ["PCSK1"], "PCSK2": ["PCSK2"], "ABCC8_KCNJ11": ["ABCC8", "KCNJ11"],
          "KRT19": ["KRT19"], "SOX9": ["SOX9"], "FOXA2": ["FOXA2"], "INS_IGF2_TH": ["INS"],
          "GAPDH": ["GAPDH"], "ACTB": ["ACTB"]}

BG = {}
for m, _, _ in TRACKS:
    fs = sorted(glob.glob(f"{DATA}/bg/{m}_r*.bedgraph"))
    if fs:
        BG[m] = [pd.read_csv(f, sep="\t", header=None, names=["c", "s", "e", "v"]) for f in fs]


def signal(m, chrom, s, e, step=50):
    xs = np.arange(s, e, step)
    reps = []
    for d in BG[m]:
        sub = d[(d.c == chrom) & (d.e > s) & (d.s < e)]
        y = np.zeros(len(xs))
        for st, en, v in sub[["s", "e", "v"]].itertuples(index=False):
            y[max(0, (st - s) // step):min(len(xs), int(np.ceil((en - s) / step)))] = v
        reps.append(y)
    return xs, np.mean(reps, 0)


def smooth(y, sigma_bins):
    k = np.arange(-4 * sigma_bins, 4 * sigma_bins + 1)
    g = np.exp(-0.5 * (k / sigma_bins) ** 2); g /= g.sum()
    return np.convolve(np.pad(y, len(k), mode="edge"), g, mode="same")[len(k):-len(k)]


# per-mark scale shared across all loci (99.5th pct of smoothed signal) so loci are comparable
SCALE = {}
for m in BG:
    v = []
    for r in win.itertuples():
        _, y = signal(m, r.chrom, r.start, r.end)
        v.append(np.percentile(smooth(y, 10), 99.5))
    SCALE[m] = max(v)


def draw_locus(ax_genes, axes, r, highlight=None):
    s, e = r.start, r.end
    # genes on top, reference-style blue chevron arrows
    g = genes[(genes.key == r.key) & ~genes.name.str.startswith("ENST")]
    g = g[(g.biotype == "protein_coding") | g.name.str.contains(r"-AS|LINC|PLUT|LNC", regex=True)]
    lanes = []
    for row in g.sort_values("start").itertuples():
        a, b = max(row.start, s), min(row.end, e)
        if b <= a:
            continue
        lane = 0
        while any(l == lane and not (a > bb + 2500 or b < aa - 2500) for l, aa, bb in lanes):
            lane += 1
        lanes.append((lane, a, b))
        y = 1.6 - lane * 1.1
        hl = row.name in TARGET.get(r.key, [])
        col = GENE_COL if hl else "#9db9d6"
        L = b - a; dx = L if row.strand == 1 else -L
        x0 = a if row.strand == 1 else b
        ax_genes.add_patch(FancyArrow(x0, y, dx, 0, width=0.32, head_width=0.62,
                                      head_length=min(L * 0.35, (e - s) * 0.012), length_includes_head=True,
                                      color=col, lw=0))
        ax_genes.text((a + b) / 2, y + 0.55, row.name, ha="center", va="bottom", fontsize=9,
                      color=col, fontweight="bold" if hl else "normal")
    nl = max([l for l, _, _ in lanes], default=0)
    ax_genes.set_ylim(1.6 - nl * 1.1 - 0.8, 3.0)
    ax_genes.set_xlim(s, e); ax_genes.axis("off")
    # tracks
    for ax, (m, lab, col) in zip(axes, [t for t in TRACKS if t[0] in BG]):
        xs, y = signal(m, r.chrom, s, e)
        y = np.clip(smooth(y, 10) / SCALE[m], 0, 1)
        ax.fill_between(xs, 0, y, color=col, lw=0)
        ax.plot(xs, y, color="#222", lw=0.6)
        ax.axhline(0, color="#222", lw=0.6)
        ax.set_ylim(0, 1.05); ax.set_xlim(s, e); ax.axis("off")
        ax.text(s + (e - s) * 0.004, 0.55, lab + (" *" if len(BG[m]) == 1 else ""), ha="left", va="center",
                fontsize=10, color="#111",
                bbox=None)
    if highlight:
        for a in [ax_genes] + list(axes):
            a.axvspan(*highlight, color="#e6f0f0", zorder=-10, lw=0)


def coord_axis(ax, chrom, s, e):
    ax.set_xlim(s, e); ax.set_ylim(0, 1)
    ax.axhline(0.15, color="#111", lw=2.5)
    ticks = np.linspace(s, e, 5)
    for t in ticks:
        ax.text(t, 0.35, f"{t/1e6:.3f} Mb", ha="center", va="bottom", fontsize=9)
        ax.plot([t, t], [0.15, 0.3], color="#111", lw=1)
    ax.text(s, 1.25, f"{chrom}  (hg38)", fontsize=11, fontweight="bold", va="bottom")
    ax.axis("off")


def figure_for(r):
    n = len([t for t in TRACKS if t[0] in BG])
    fig = plt.figure(figsize=(9, 1.0 + 0.9 + 0.62 * n))
    gs = fig.add_gridspec(2 + n, 1, height_ratios=[0.55, 1.15] + [0.62] * n, hspace=0.08)
    ax_c = fig.add_subplot(gs[0]); ax_g = fig.add_subplot(gs[1])
    axes = [fig.add_subplot(gs[2 + i]) for i in range(n)]
    coord_axis(ax_c, r.chrom, r.start, r.end)
    # highlight target gene body +/- 3 kb
    tg = genes[(genes.key == r.key) & genes.name.isin(TARGET[r.key])]
    hl = (tg.start.min() - 3000, tg.end.max() + 3000) if len(tg) else None
    draw_locus(ax_g, axes, r, highlight=hl)
    fig.text(0.99, 0.005, "Smoothed CPM (mean of 2 replicates; * = replicate 1 only), each mark scaled identically across all loci.  "
             "HPDE6-E6E7, hg38.", ha="right", fontsize=6.5, color="#555")
    return fig


for r in win.itertuples():
    fig = figure_for(r)
    fig.savefig(f"{OUT}/refstyle_{r.key}.png", dpi=220, bbox_inches="tight")
    fig.savefig(f"{OUT}/refstyle_{r.key}.pdf", bbox_inches="tight")
    plt.close(fig)

# multi-panel overview: 4 x 4 grid of all 15 loci + legend
order = ["PDX1", "NEUROG3", "NKX6-1", "MAFA", "PAX6", "NEUROD1", "PCSK1", "PCSK2", "ABCC8_KCNJ11",
         "INS_IGF2_TH", "FOXA2", "SOX9", "KRT19", "GAPDH", "ACTB"]
n = len([t for t in TRACKS if t[0] in BG])
fig = plt.figure(figsize=(20, 22))
outer = fig.add_gridspec(4, 4, hspace=0.25, wspace=0.08, top=0.965, bottom=0.03)
for i, key in enumerate(order):
    r = win[win.key == key].iloc[0]
    sub = outer[i // 4, i % 4].subgridspec(1 + n, 1, height_ratios=[1.3] + [0.6] * n, hspace=0.06)
    ax_g = fig.add_subplot(sub[0]); axes = [fig.add_subplot(sub[1 + j]) for j in range(n)]
    tg = genes[(genes.key == key) & genes.name.isin(TARGET[key])]
    draw_locus(ax_g, axes, r, highlight=(tg.start.min() - 3000, tg.end.max() + 3000))
    for ax in axes:
        for t in ax.texts:
            t.set_visible(i % 4 == 0)
    ax_g.set_title(f"{key.replace('_', ' / ')}   {r.chrom}:{r.start/1e6:.2f}-{r.end/1e6:.2f} Mb", fontsize=11,
                   loc="left")
lax = fig.add_subplot(outer[3, 3]); lax.axis("off")
for j, (m, lab, col) in enumerate([t for t in TRACKS if t[0] in BG]):
    lax.add_patch(Rectangle((0.05, 0.8 - j * 0.14), 0.12, 0.09, color=col))
    lax.text(0.22, 0.845 - j * 0.14, lab + (" (rep 1)" if len(BG[m]) == 1 else ""), va="center", fontsize=13)
lax.text(0.05, 0.05, "Shaded = target gene ±3 kb\nSignal scaled identically per mark", fontsize=11, color="#444")
lax.set_xlim(0, 1); lax.set_ylim(0, 1)
fig.suptitle("HPDE6-E6E7 baseline chromatin at islet / ductal target genes", fontsize=17, x=0.125, ha="left", y=0.99)
fig.savefig(f"{OUT}/refstyle_overview.png", dpi=170, bbox_inches="tight")
fig.savefig(f"{OUT}/refstyle_overview.pdf", bbox_inches="tight")
print("done")
